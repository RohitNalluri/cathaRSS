import { Notice } from 'obsidian';
import { LLMService } from './llm';
import { NoteWriter, SourceType } from './noteWriter';
import { ReadItAllSettings } from './settings';

interface ClipPayload {
	title: string;
	url: string;
	content: string;
	selectedText?: string;
	source: SourceType;
	author?: string;
}

export class ClipperServer {
	private settings: ReadItAllSettings;
	private llm: LLMService;
	private noteWriter: NoteWriter;
	private server: any = null; // Node http.Server

	constructor(settings: ReadItAllSettings, llm: LLMService, noteWriter: NoteWriter) {
		this.settings = settings;
		this.llm = llm;
		this.noteWriter = noteWriter;
	}

	async start(): Promise<void> {
		if (this.server) return;

		try {
			// Use Node's built-in http module (available in Obsidian's Electron env)
			const http = require('http');

			this.server = http.createServer(async (req: any, res: any) => {
				// CORS headers so the extension can talk to localhost
				res.setHeader('Access-Control-Allow-Origin', '*');
				res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
				res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

				if (req.method === 'OPTIONS') {
					res.writeHead(204);
					res.end();
					return;
				}

				if (req.method === 'POST' && req.url === '/clip') {
					let body = '';
					req.on('data', (chunk: any) => { body += chunk.toString(); });
					req.on('end', async () => {
						try {
							const payload: ClipPayload = JSON.parse(body);
							await this.handleClip(payload);
							res.writeHead(200, { 'Content-Type': 'application/json' });
							res.end(JSON.stringify({ success: true }));
						} catch (err) {
							console.error('Read It All clipper error:', err);
							res.writeHead(500, { 'Content-Type': 'application/json' });
							res.end(JSON.stringify({ success: false, error: String(err) }));
						}
					});
				} else if (req.method === 'GET' && req.url === '/ping') {
					res.writeHead(200, { 'Content-Type': 'application/json' });
					res.end(JSON.stringify({ status: 'ok', plugin: 'read-it-all' }));
				} else {
					res.writeHead(404);
					res.end();
				}
			});

			this.server.listen(this.settings.clipperPort, '127.0.0.1', () => {
				console.log(`Read It All: Clipper server running on port ${this.settings.clipperPort}`);
			});

		} catch (err) {
			console.error('Read It All: Failed to start clipper server:', err);
			new Notice('Read It All: Could not start clipper server. Check console.');
		}
	}

	stop(): void {
		if (this.server) {
			this.server.close();
			this.server = null;
			console.log('Read It All: Clipper server stopped.');
		}
	}

	private async handleClip(payload: ClipPayload): Promise<void> {
		const content = payload.selectedText || payload.content;

		const summary = this.settings.apiKey
			? await this.llm.summarizeArticle(payload.title, content)
			: undefined;

		await this.noteWriter.saveArticle({
			title: payload.title,
			url: payload.url,
			author: payload.author,
			content,
			source: payload.source,
			summary,
			capturedAt: new Date(),
		});

		new Notice(`📎 Clipped: ${payload.title.slice(0, 50)}`);
	}
}
