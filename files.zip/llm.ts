import { ReadItAllSettings } from './settings';

export interface ArticleSummary {
	bullets: string[];
	keyQuotes: string[];
}

export class LLMService {
	private settings: ReadItAllSettings;

	constructor(settings: ReadItAllSettings) {
		this.settings = settings;
	}

	private getEndpoint(): string {
		if (this.settings.llmProvider === 'openrouter') {
			return 'https://openrouter.ai/api/v1/chat/completions';
		}
		return 'https://api.openai.com/v1/chat/completions';
	}

	private getHeaders(): Record<string, string> {
		const headers: Record<string, string> = {
			'Content-Type': 'application/json',
			'Authorization': `Bearer ${this.settings.apiKey}`,
		};
		if (this.settings.llmProvider === 'openrouter') {
			headers['HTTP-Referer'] = 'obsidian-read-it-all';
			headers['X-Title'] = 'Read It All';
		}
		return headers;
	}

	async complete(systemPrompt: string, userPrompt: string): Promise<string> {
		const response = await fetch(this.getEndpoint(), {
			method: 'POST',
			headers: this.getHeaders(),
			body: JSON.stringify({
				model: this.settings.model,
				messages: [
					{ role: 'system', content: systemPrompt },
					{ role: 'user', content: userPrompt }
				],
				temperature: 0.3,
				max_tokens: 1000,
			})
		});

		if (!response.ok) {
			const err = await response.text();
			throw new Error(`LLM API error: ${response.status} — ${err}`);
		}

		const data = await response.json();
		return data.choices[0].message.content.trim();
	}

	async summarizeArticle(title: string, content: string): Promise<ArticleSummary> {
		const systemPrompt = `You are a precise reading assistant. When given an article, you extract the key ideas and notable quotes. 
Always respond in valid JSON matching this shape exactly:
{
  "bullets": ["point 1", "point 2", "point 3"],
  "keyQuotes": ["quote 1", "quote 2"]
}
Bullets should be 1-2 sentences each. Key quotes should be verbatim from the text. Return 2-4 quotes maximum. If there are no notable quotes, return an empty array.`;

		const userPrompt = `Title: ${title}

Article content:
${content.slice(0, 6000)}`; // cap to avoid token limits

		const raw = await this.complete(systemPrompt, userPrompt);

		try {
			// Strip markdown code fences if model wraps in them
			const cleaned = raw.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
			return JSON.parse(cleaned) as ArticleSummary;
		} catch {
			// Fallback if JSON parsing fails
			return {
				bullets: ['Summary unavailable — open article for full content.'],
				keyQuotes: [],
			};
		}
	}

	async generateDigest(
		articles: DigestArticle[],
		interestProfile: string
	): Promise<string> {
		const systemPrompt = `You are a helpful reading assistant generating a weekly digest. 
Given a list of articles captured this week, pick the 3-5 most worth reading based on the user's interest profile.
For each recommendation, give a one-sentence reason why.
Format your response as a markdown list like:
- **[Article Title]** — reason why it's worth reading
Only recommend articles from the provided list.`;

		const articleList = articles
			.map((a, i) => `${i + 1}. "${a.title}" (${a.source}) — ${a.bullets[0] ?? ''}`)
			.join('\n');

		const userPrompt = `User interest profile: ${interestProfile || 'General curiosity across technology, ideas, and culture.'}

Articles this week:
${articleList}`;

		return this.complete(systemPrompt, userPrompt);
	}
}

export interface DigestArticle {
	title: string;
	url: string;
	source: string;
	bullets: string[];
}
