import { Plugin, Notice } from 'obsidian';
import { ReadItAllSettings, DEFAULT_SETTINGS } from './settings';
import { ReadItAllSettingTab } from './settingsTab';
import { LLMService } from './llm';
import { NoteWriter } from './noteWriter';
import { RSSFetcher } from './rssFetcher';
import { ClipperServer } from './clipperServer';
import { DigestGenerator } from './digestGenerator';

export default class ReadItAllPlugin extends Plugin {
	settings: ReadItAllSettings;

	private llm: LLMService;
	private noteWriter: NoteWriter;
	private rssFetcher: RSSFetcher;
	private clipperServer: ClipperServer;
	private digestGenerator: DigestGenerator;

	private rssInterval: number | null = null;
	private digestCheckInterval: number | null = null;

	async onload() {
		await this.loadSettings();
		this.initServices();

		// Settings tab
		this.addSettingTab(new ReadItAllSettingTab(this.app, this));

		// Commands (accessible via Cmd+P)
		this.addCommand({
			id: 'fetch-rss',
			name: 'Fetch RSS feeds now',
			callback: async () => {
				new Notice('Read It All: Fetching RSS feeds...');
				await this.fetchRSSFeeds();
			}
		});

		this.addCommand({
			id: 'generate-digest',
			name: 'Generate weekly digest now',
			callback: async () => {
				new Notice('Read It All: Generating digest...');
				await this.generateWeeklyDigest();
				new Notice('Read It All: Digest ready! Check your Digests folder.');
			}
		});

		// Ribbon icon for quick clip
		this.addRibbonIcon('bookmark', 'Read It All', () => {
			new Notice('Read It All: Use the Chrome extension to clip pages, or Cmd+P for commands.');
		});

		// Start background processes
		this.startRSSInterval();
		this.startDigestCheck();

		if (this.settings.clipperEnabled) {
			await this.startClipperServer();
		}

		console.log('Read It All: Plugin loaded.');
	}

	onunload() {
		this.stopClipperServer();
		if (this.rssInterval) window.clearInterval(this.rssInterval);
		if (this.digestCheckInterval) window.clearInterval(this.digestCheckInterval);
		console.log('Read It All: Plugin unloaded.');
	}

	async loadSettings() {
		this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData());
	}

	async saveSettings() {
		await this.saveData(this.settings);
		// Re-init services with updated settings
		this.initServices();
	}

	// ── Public methods (called from settings UI) ──────────────────────────────

	async fetchRSSFeeds(): Promise<void> {
		await this.rssFetcher.fetchAll();
		this.settings.lastRssFetch = new Date().toISOString();
		await this.saveData(this.settings);
	}

	async generateWeeklyDigest(): Promise<void> {
		await this.digestGenerator.generate();
		this.settings.lastDigestGenerated = new Date().toISOString();
		await this.saveData(this.settings);
	}

	async startClipperServer(): Promise<void> {
		await this.clipperServer.start();
	}

	stopClipperServer(): void {
		this.clipperServer.stop();
	}

	// ── Private ────────────────────────────────────────────────────────────────

	private initServices(): void {
		this.llm = new LLMService(this.settings);
		this.noteWriter = new NoteWriter(this.app, this.settings);
		this.rssFetcher = new RSSFetcher(this.settings, this.llm, this.noteWriter);
		this.clipperServer = new ClipperServer(this.settings, this.llm, this.noteWriter);
		this.digestGenerator = new DigestGenerator(this.app, this.settings, this.llm, this.noteWriter);
	}

	private startRSSInterval(): void {
		if (this.rssInterval) window.clearInterval(this.rssInterval);
		const ms = this.settings.rssFetchIntervalHours * 60 * 60 * 1000;
		this.rssInterval = window.setInterval(async () => {
			await this.fetchRSSFeeds();
		}, ms);
	}

	private startDigestCheck(): void {
		if (this.digestCheckInterval) window.clearInterval(this.digestCheckInterval);
		// Check every hour if it's time to generate the digest
		this.digestCheckInterval = window.setInterval(async () => {
			if (this.digestGenerator.shouldGenerateToday()) {
				await this.generateWeeklyDigest();
				new Notice('Read It All: Weekly digest generated!');
			}
		}, 60 * 60 * 1000);
	}
}
